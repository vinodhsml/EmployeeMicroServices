﻿namespace EmployeesMicroServices.Models
{
    public class EmployeeModel
    {
        public int Id { get; set; }
        public string EName { get; set; }
        public string Job { get; set; }
        public int Salary { get; set; }
    }
}
